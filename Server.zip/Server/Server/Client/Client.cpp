﻿#include "pch.h"

int main()
{
    HelloWorld();
}
