﻿#include "pch.h"
#include "CorePch.h"

void HelloWorld()
{
	cout << "Hello Library!!!" << endl;
}